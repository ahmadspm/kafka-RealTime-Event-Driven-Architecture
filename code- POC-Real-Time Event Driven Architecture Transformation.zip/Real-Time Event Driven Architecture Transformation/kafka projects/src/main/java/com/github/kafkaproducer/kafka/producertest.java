package com.github.kafkaproducer.kafka;

import com.sun.istack.internal.NotNull;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.Properties;

public class producertest {
    public static  void main(String[] args) {
System.out.println("Hello to producer");
String bootstrapper= "127.0.0.1:9092";
// create producer properties
        Properties properties= new Properties();
        properties.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapper);
        properties.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        properties.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());

        // create producer
        KafkaProducer<String, String> producer;
        producer = new KafkaProducer<String,String>(properties);

        // crete producer record
       ProducerRecord<String,String> record;
        record = new ProducerRecord<String,String>("first_topic", "this is an event\n ");
        //  send data
        for (int i=0; i<=25; i++) {
        //for (int i = 0; i < 100; i++){
           producer.send(new ProducerRecord<String, String>("first_topic", Integer.toString(i), Integer.toString(i)));
            producer.send(record);
            producer.flush();
        }
            producer.close();

    }
}
