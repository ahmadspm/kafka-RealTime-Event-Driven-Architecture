package com.github.kafkaproducer.kafka;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

public class producertestwithcallback {
    public static  void main(String[] args) {
        // create a logger for producercallack class
        final Logger logger= LoggerFactory.getLogger(producertestwithcallback.class);
System.out.println("Hello to producer");
String bootstrapper= "127.0.0.1:9092";
// create producer properties
        Properties properties= new Properties();
        properties.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapper);
        properties.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        properties.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());

        // create producer
        KafkaProducer<String, String> producer;
        producer = new KafkaProducer<String,String>(properties);

        // crete producer record
       final ProducerRecord<String,String> record;
        record = new ProducerRecord<String,String>("first_topic", "this is an event\n ");
        //  send data
        //for (int i=0; i<=25; i++) {
        //for (int i = 0; i < 100; i++){
          // producer.send(new ProducerRecord<String, String>("first_topic", Integer.toString(i), Integer.toString(i)));
          for(int i=0; i<10; i++) {
              producer.send(record, new Callback() {
                  //execute every time when producer sends some record or throw some exception
                  public void onCompletion(RecordMetadata recordMetadata, Exception e) {
                      if (e == null)
                      //record was successfully sent
                      {
                          logger.info("Recived new metadata \n" +
                                  "topic:" + recordMetadata.topic() + "\n"
                                  + "partition: " + recordMetadata.partition() + "\n"
                                  + "offset: " + recordMetadata.offset() + "\n"
                                  + "Timestamp: " + recordMetadata.timestamp());
                      } else {
                          logger.error("Error while producing events", e);
                          e.printStackTrace();

                      }

                  }
              });
              producer.flush();
          }
            producer.close();

    }
}
